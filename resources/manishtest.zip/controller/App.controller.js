sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("manishtest.controller.App",{onInit:function(){}})});
//# sourceMappingURL=App.controller.js.map